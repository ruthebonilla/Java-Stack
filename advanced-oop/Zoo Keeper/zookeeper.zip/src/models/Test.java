package models;

public class Test {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		//System.out.println("hello world");
		
		
//		Mammal energy = new Mammal();
//		System.out.println(energy.getEnergyLevel());
//		
//		Gorilla friendlyGorilla = new Gorilla();
//		friendlyGorilla.throwSomething();
//		friendlyGorilla.throwSomething();
//		friendlyGorilla.throwSomething();
//		friendlyGorilla.eatBananas();
//		friendlyGorilla.eatBananas();
//		friendlyGorilla.climb();
		
		
		
		
		Bat evilBat = new Bat();
		evilBat.fly();
		evilBat.fly();
		evilBat.attackTown();
		evilBat.attackTown();
		evilBat.attackTown();
		evilBat.eatHuman();
		evilBat.eatHuman();
		
		
	}

}
